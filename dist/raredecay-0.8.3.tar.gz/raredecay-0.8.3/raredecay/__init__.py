"""Initialization of rare-decay
"""
